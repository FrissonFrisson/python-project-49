### Hexlet tests and linter status:
[![Actions Status](https://github.com/FrissonFrisson/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/FrissonFrisson/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/d86f051eab34933b9ec6/maintainability)](https://codeclimate.com/github/FrissonFrisson/python-project-49/maintainability)